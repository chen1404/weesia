<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <!-- Form Section -->
    <section>
        <div class="flex justify-between h-screen">
            <div class="hidden sm:block h-screen w-[34%] bg-date-bg bg-cover">
            </div>
            <!--  sm:bg-primary lg:bg-teal-400 xl:bg-teal-600 -->
            <div class="w-full md:w-8/12 primary-opacity flex flex-col justify-center xl:items-center">
                <div class="flex flex-col justify-between h-[12%] lg:h-[15%] mb-4">
                    <h1 class="font-bold text-[32px] lg:text-4xl xl:text-5xl text-center">Ubah Tugas</h1>
                    <h2 class="font-bold text-xl lg:text-2xl xl:text-3xl text-center">09 Desember 2022</h2>
                </div>
                <form action="post" class="flex flex-col justify-evenly h-[30%] lg:h-[40%] px-16 lg:px-28 xl:w-3/4 ">
                    <label for="tanggal" class="text-sm lg:text-base xl:text-lg font-medium">
                        Tanggal
                        <input type="text" name="date" id="tanggal" placeholder="waktu rekapan" class="p-1 rounded-md w-full" required>
                    </label>
                    <label for="tanggal" class="text-sm lg:text-base xl:text-lg font-medium">
                        Link
                        <input type="text" name="date" id="tanggal" placeholder="file rekapan" class="p-1 rounded-md w-full" required>
                    </label>
                    <button type="submit" class="bg-amber-400 text-white lg:text-lg xl:text-xl p-[5px] rounded-md hover:bg-amber-300">Ubah</button>
                    <a href="/rekapan-crud" class="text-center bg-dark text-white lg:text-lg xl:text-xl p-[5px] rounded-md hover:opacity-80">Batal</a>
                </form>
            </div>
        </div>
    </section>
    <!-- End Form Section -->
</body>
</html><?php /**PATH C:\laravel\weesia\resources\views/rekapan_update.blade.php ENDPATH**/ ?>