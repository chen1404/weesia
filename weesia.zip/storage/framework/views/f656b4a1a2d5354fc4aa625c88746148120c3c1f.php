<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon picture" href="<?php echo e(asset('img/logo/code.png')); ?>">
    <title>Weesia Member - <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <!-- Form Section -->
    <section>
        <div class="flex justify-between h-screen">
            <div class="hidden sm:block h-screen w-[34%] <?php echo $__env->yieldContent('bg-form'); ?> bg-cover">
            </div>
            <div class="w-full md:w-8/12 primary-opacity flex flex-col justify-center xl:items-center">
                <div class="flex flex-col mb-4">
                    <h1 class="font-bold text-[32px] lg:text-4xl text-center"><?php echo $__env->yieldContent('form-title'); ?></h1>
                    
                </div>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </section>
    <!-- End Form Section -->

    <?php echo $__env->yieldContent('extend-js'); ?>
</body>
</html><?php /**PATH C:\laravel\weesia\resources\views/layouts/components/form.blade.php ENDPATH**/ ?>