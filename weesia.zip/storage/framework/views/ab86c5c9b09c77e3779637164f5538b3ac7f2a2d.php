

<?php $__env->startSection('title'); ?>
    Rekapan Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bg-form'); ?>
    bg-date-bg
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form-title'); ?>
    Tambah Tugas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__errorArgs = ['dateFrom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="font-semibold text-sm text-red-500 text-center"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['dateTo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="font-semibold text-sm text-red-500 text-center"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="font-semibold text-sm text-red-500 text-center"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
    <form method="post" action="/member/rekapan/creating" class="flex flex-col px-16 lg:px-28 xl:w-3/4 ">
        <?php echo csrf_field(); ?>
        <div class="mb-6 flex flex-col">
            <label for="tanggal" class="flex flex-col text-sm lg:text-base xl:text-lg font-medium">
                Tanggal
                <div class="w-full flex items-center mb-2">
                    <input type="date" name="dateFrom" id="tanggal" class="p-1 rounded-md w-full border-none focus:ring-sky-500 focus:ring-2" required>
                    <span class="ml-4 font-semibold">hingga</span>
                </div>
                <input type="date" name="dateTo" id="tanggal" class="p-1 rounded-md w-full border-none focus:ring-sky-500 focus:ring-2" required>
            </label>
            <label for="link" class="text-sm lg:text-base xl:text-lg font-medium">
                Link
                <input type="url" name="link" id="link" placeholder="file rekapan" class="p-1 rounded-md w-full border-none focus:ring-sky-500 focus:ring-2" required>
            </label>
        </div>
        <div class="flex flex-col">
            <button type="submit" class="bg-sky-500 text-white lg:text-lg xl:text-xl p-[5px] rounded-md hover:opacity-80 mb-2">Tambah</button>
            <a href="/member/rekapan" class="text-center bg-dark text-white lg:text-lg xl:text-xl p-[5px] rounded-md hover:opacity-80">Batal</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.components.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\weesia\resources\views/member/rekapan/create.blade.php ENDPATH**/ ?>