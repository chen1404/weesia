<nav class="navbar navbar-expand-lg navbar-light navbar-store fixed-top navbar-fixed-top" data-aos="fade-down">
    <div class="container">
        <a href="#" class="navbar-brand">
            <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="logo" />
        </a>
        <?php if(Auth::user()): ?>
            <span class="fs-4">Selamat Datang <b><?php echo e(Auth::user()->name ?? 'HomePage'); ?></b></span>
        <?php endif; ?>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item ">
                    <a href="#"
                        class="nav-link">Home</a>
                </li>
                <?php if(Auth::user()): ?>
                    <?php if(Auth::user()->role == 'pembeli'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('user.transaksi')); ?>" class="nav-link" aria-current="page">Profil</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('pembeli.keranjang')); ?>" class="nav-link" aria-current="page">Keranjang
                                &nbsp;&nbsp;
                                <img src="/images/icon-cart-filled.svg" alt="" />
                                <div class="card-badge"><?php echo e($keranjang); ?></div>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link">Sign Up</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <?php $stat = Auth::user() ? 'logout' : 'login' ?>
                    <a class="btn btn-primary" href="#" class="nav-link " aria-current="page">
                        <?php echo e(ucfirst($stat)); ?>

                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\laravel\weesia\resources\views/includes/navbar.blade.php ENDPATH**/ ?>