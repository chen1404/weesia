

<?php $__env->startSection('title'); ?>
    Admin Dashboard
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('body-class'); ?>
    h-screen bg-light flex flex-col justify-between
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active_absen'); ?>
    active-page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <!-- Hero Section -->
        <section class="pt-20 lg:pt-24">
            <div class="sm:container px-4">
                <div class="">
                    <div class="text-center lg:text-start">
                        <h2 class="font-medium text-xl lg:text-2xl">WEESIA ADMIN</h2>
                        <h1 class="font-bold text-3xl lg:text-4xl mb-6 lg:mb-8">Absen Dashboard</h1>
                    </div>
                    <div class="flex flex-row overflow-scroll justify-between no-scrollbar">
                        <div class="flex items-center md:w-full bg-white border border-gray rounded-lg w-fit p-4 mx-2 lg:ml-0">
                            <div class="w-[50px] h-[50px] bg-sky-400 bg-opacity-40 rounded-md p-2 mr-2">
                                <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="rgb(56 189 248)"><title>Bot</title><path d="M23.5154 13.4558c-.2744-1.8854-.692-3.7828-.9904-5.0477-.358-1.5035-1.6349-2.5775-3.1742-2.673-1.5155-.0955-4.0215-.2028-7.3627-.2028-3.3413 0-5.8472.1074-7.3627.2028-1.5394.0955-2.8163 1.1695-3.1743 2.673-.2983 1.265-.716 3.1623-.9904 5.0477-.191 1.2769-.3341 2.7685-.4535 4.463-.0596.9427.2506 1.8496.8831 2.5537.6324.704 1.4916 1.1217 2.4463 1.1575 2.0763.0955 5.2625.2148 8.6634.2148 3.401 0 6.587-.1193 8.6634-.2148.9427-.0477 1.8139-.4535 2.4463-1.1575.6325-.704.9427-1.611.883-2.5537-.1312-1.6945-.2863-3.198-.4773-4.463zm-1.6467 5.9188c-.3342.37-.7876.5848-1.2888.6086-2.0644.0955-5.2148.2148-8.5918.2148-3.3771 0-6.5274-.1193-8.5919-.2148-.5011-.0239-.9546-.2386-1.2887-.6086-.3342-.3699-.5012-.8472-.4654-1.3484.1074-1.6468.2506-3.1026.4415-4.3317.2625-1.8258.6683-3.6754.9666-4.9045.191-.7995.8592-1.3604 1.6826-1.42C6.2244 7.2745 8.6945 7.167 12 7.167c3.2935 0 5.7756.1074 7.2673.2029.8114.0477 1.4916.6205 1.6825 1.42.2864 1.2291.6921 3.0787.9666 4.9045.179 1.2291.3222 2.685.4415 4.3317 0 .5012-.167.9785-.4892 1.3484zM11.988 4.1958c.5608 0 1.0262-.4535 1.0262-1.0143 0-.561-.4534-1.0263-1.0262-1.0263-.5609 0-1.0263.4535-1.0263 1.0263 0 .5489.4654 1.0143 1.0263 1.0143zm5.9665 7.84c-.9069 0-1.6468.7399-1.6468 1.6468h3.2936c0-.907-.728-1.6468-1.6468-1.6468zm-11.933 0c-.907 0-1.6468.7399-1.6468 1.6468h3.2935c0-.907-.728-1.6468-1.6468-1.6468zm5.9665 5.9665c1.4677 0 2.661-1.1933 2.661-2.661h-5.334c0 1.4558 1.1933 2.661 2.673 2.661z"/></svg>
                            </div>
                            <div>
                                <h3 class="font-normal text-base lg:text-lg whitespace-nowrap">Jumlah Bot</h3>
                                <h2 class="font-semibold text-xl lg:text-2xl">87</h2>
                            </div>
                        </div>
                        <div class="flex items-center md:w-full bg-white border border-gray rounded-lg w-fit p-4 mx-2">
                            <div class="w-[50px] h-[50px] bg-[#F62B61] bg-opacity-40 rounded-md p-3 mr-2">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="rgb(246 43 97)"><title>Cloning</title><path d="M64 464H288C296.8 464 304 456.8 304 448V384H352V448C352 483.3 323.3 512 288 512H64C28.65 512 0 483.3 0 448V224C0 188.7 28.65 160 64 160H128V208H64C55.16 208 48 215.2 48 224V448C48 456.8 55.16 464 64 464zM160 64C160 28.65 188.7 0 224 0H448C483.3 0 512 28.65 512 64V288C512 323.3 483.3 352 448 352H224C188.7 352 160 323.3 160 288V64zM224 304H448C456.8 304 464 296.8 464 288V64C464 55.16 456.8 48 448 48H224C215.2 48 208 55.16 208 64V288C208 296.8 215.2 304 224 304z"/></svg>
                            </div>
                            <div>
                                <h3 class="font-normal text-base lg:text-lg whitespace-nowrap">Total Clone</h3>
                                <h2 class="font-semibold text-xl lg:text-2xl">42</h2>
                            </div>
                        </div>
                        <div class="flex items-center md:w-full bg-white border border-gray rounded-lg w-fit p-4 mx-2 lg:mr-0">
                            <div class="w-[50px] h-[50px] bg-green-400 bg-opacity-40 rounded-md p-3 mr-2">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="rgb(49 196 141)"><title>Calender</title><path d="M7 11h2v2H7zm0 4h2v2H7zm4-4h2v2h-2zm0 4h2v2h-2zm4-4h2v2h-2zm0 4h2v2h-2z"></path><path d="M5 22h14c1.103 0 2-.897 2-2V6c0-1.103-.897-2-2-2h-2V2h-2v2H9V2H7v2H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2zM19 8l.001 12H5V8h14z"></path></svg>
                            </div>
                            <div>
                                <h3 class="font-normal text-base lg:text-lg whitespace-nowrap">Kehadiran</h3>
                                <h2 class="font-semibold text-xl lg:text-2xl">76%</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Section -->
    
    
        <!-- Absen Table Section -->
        <section class="py-10">
            <div class="sm:container px-4">
                <!-- Absen Clone -->
                <div class="bg-white border border-gray mb-6">
                    <div class="flex lg:justify-between items-center p-3 overflow-scroll no-scrollbar">
                        <div class="md:block hidden whitespace-nowrap">
                            <h1 class="font-bold text-2xl lg:text-3xl">Absen Clone</h1>
                        </div>
                        <div class="flex items-center md:justify-end">
                            <a href="#" class="bg-primary text-white rounded-lg px-3 lg:px-4 py-2 mr-2">Export</a>
                            <span onclick="hello()" class="flex items-center border border-gray font-semibold rounded-lg cursor-pointer lg:px-4 p-2 mr-2">
                                <p>Kategori</p> 
                                <div class="w-[20px] ml-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M10 3H4a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zM9 9H5V5h4v4zm11 4h-6a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1zm-1 6h-4v-4h4v4zM17 3c-2.206 0-4 1.794-4 4s1.794 4 4 4 4-1.794 4-4-1.794-4-4-4zm0 6c-1.103 0-2-.897-2-2s.897-2 2-2 2 .897 2 2-.897 2-2 2zM7 13c-2.206 0-4 1.794-4 4s1.794 4 4 4 4-1.794 4-4-1.794-4-4-4zm0 6c-1.103 0-2-.897-2-2s.897-2 2-2 2 .897 2 2-.897 2-2 2z"/></svg>
                                </div>
                            </span>
                            <span class="flex items-center border border-gray font-semibold rounded-lg lg:px-4 p-2 mr-2">
                                <p>Urutkan</p> 
                                <div class="w-[15px] ml-2">
                                    <svg viewBox="0 0 512 448" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17.4119 29.4131L17.44 29.3548L17.4675 29.2963C21.5958 20.5393 30.3166 15 39.9997 15H472C481.683 15 490.404 20.5393 494.532 29.2963C498.674 38.0819 497.415 48.3985 491.285 55.9083C491.284 55.9095 491.283 55.9108 491.282 55.912L308.391 279.4L305 283.545V288.9V416C305 422.457 301.379 428.316 295.641 431.159C289.728 434.088 282.905 433.442 277.819 429.615L277.81 429.607L277.8 429.6L213.8 381.6L213.764 381.573L213.728 381.547C209.521 378.43 207 373.44 207 368V288.9V283.544L203.608 279.4L20.6264 55.8227C20.6236 55.8193 20.6209 55.8159 20.6181 55.8126C14.5425 48.351 13.2833 37.9783 17.4119 29.4131Z" stroke="black" stroke-width="60"/></svg>
                                </div>
                            </span>
                            <form class="flex justify-between items-center min-w-[120px] w-full md:w-[25%] lg:w-full border border-gray rounded-lg p-2">
                                <input type="text" placeholder="Cari" class="border-none focus:ring-0 w-full p-0">
                                <div class="cursor-pointer border-l border-slate-500 pl-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="15px" viewBox="0 0 512 512" fill="rgb(116,123,136)"><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352c79.5 0 144-64.5 144-144s-64.5-144-144-144S64 128.5 64 208s64.5 144 144 144z"/></svg>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="overflow-scroll no-scrollbar">
                        <table class="text-center">
                            <thead>
                                <tr class="whitespace-nowrap ">
                                    <th class="p-3 border border-l-0 border-gray bg-white outline outline-1 outline-gray sticky left-0">NAMA</th>
                                    <th class="p-3 border border-gray">01 Desember 2022</th>
                                    <th class="p-3 border border-gray">02 Desember 2022</th>
                                    <th class="p-3 border border-gray">03 Desember 2022</th>
                                    <th class="p-3 border border-gray">04 Desember 2022</th>
                                    <th class="p-3 border border-gray">05 Desember 2022</th>
                                    <th class="p-3 border border-gray">06 Desember 2022</th>
                                </tr>
                            </thead>
                            <tbody class="">
                                <!-- 1st data -->
                                <tr class="border-b border-gray">
                                    <td rowspan="2" class="border-r border-gray bg-white outline outline-1 outline-gray sticky left-0">Acun</td>
                                    <td class="border-r border-gray">Absen</td>
                                    <td class="border-r border-gray">Alpha</td>
                                </tr>
                                <tr class="border-b border-dark">
                                    <td class="border-r border-gray">12</td>
                                    <td class="border-r border-gray">22</td>
                                </tr>
                                <!-- New data -->
                                <tr class="border-b border-gray">
                                    <td rowspan="2" class="border-r border-gray bg-white outline outline-1 outline-gray sticky left-0">Hendi</td>
                                    <td class="border-r border-gray">Absen</td>
                                    <td class="border-r border-gray">Absen</td>
                                </tr>
                                <tr class="border-b border-dark">
                                    <td class="border-r border-gray">14</td>
                                    <td class="border-r border-gray">42</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </section>
        <!-- End Absen Table Section -->
    </main>

    <script>
        function hello() {
            console.log('Hello');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pages.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\weesia\resources\views/member/dashboard/absen.blade.php ENDPATH**/ ?>