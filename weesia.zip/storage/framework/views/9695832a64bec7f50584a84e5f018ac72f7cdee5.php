<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <!-- Header -->
    <header class="bg-transparent absolute top-0 left-0 w-full flex items-center z-10">
        <div class="sm:container px-4 w-full">
            <div class="flex items-center justify-between relative">
                <div class="">
                    <a href="#home" class="font-bold text-xl text-dark block my-6">WEESIA</a>
                </div>
                <div class="flex items-center px-4">
                    <nav id="nav-menu" class="hidden absolute py-5 bg-white shadow-xl rounded-lg max-w-[250px] w-full right-4 top-full lg:block lg:static lg:bg-transparent lg:max-w-full lg:shadow-none lg:rounded-none">
                        <ul class="block lg:flex">
                            <li class="group">
                                <a href="/" class="navbar-menu">Home</a>
                            </li>
                            <li class="group">
                                <a href="/rekapan" class="navbar-menu active-page">Rekapan</a>
                            </li>
                            <li class="group">
                                <a href="#" class="navbar-menu">Aplikasi</a>
                            </li>
                            <li class="group">
                                <a href="#" class="navbar-menu">Kontak</a>
                            </li>
                        </ul>
                    </nav>
                </div>

                <div class="mr-12 lg:mr-0">
                    <a href="/auth/logout" class="py-[6px] px-3 rounded-lg text-white hover:opacity-80 bg-primary text-base hover:cursor-pointer transition duration-700">Logout</a>
                </div>
                
                <button id="hamburger" name="hamburger" type="button" class="block absolute right-0 lg:hidden">
                    <span class="hamburger-line transition duration-700 ease-in-out origin-top-left"></span>
                    <span class="hamburger-line transition duration-700 ease-in-out"></span>
                    <span class="hamburger-line transition duration-700 ease-in-out origin-bottom-left"></span>
                </button>
            </div>
        </div>
    </header>
    <!-- End Header -->

    <!-- Rekap Section -->
    <section class="mt-20 lg:py-14">
        <div class="sm:container px-4">
            <div class="flex flex-col-reverse lg:flex-row justify-between items-center lg:items-start">
                <div class="w-full lg:w-4/5 primary-opacity mt-6 lg:mt-0 rounded-[4px]">
                    <div href="https://www.google.com" onclick="window.location='/'" class="bg-white group hover:bg-slate-100 hover:cursor-pointer m-1 lg:m-3 p-4 lg:p-8 rounded-[4px] flex justify-between items-center">
                        <div>
                            <h4 class="font-bold text-sm lg:text-lg">Tugas 105</h4>
                            <p class="text-[10px] mt-4 font-medium lg:text-base">15 September 2022 - 30 September 2022</p>
                        </div>
                        <div class="flex items-center">
                            <?php if(Auth::user()->level == 'admin'): ?>
                                <a href="/rekapan-update" title="Update" class="block lg:hidden lg:group-hover:block hover:text-amber-400 transition duration-300">
                                    <i class="fa-sharp fa-solid fa-circle-dot text-[22px] lg:text-4xl"></i>
                                </a>
                                <a href="/rekapan-delete" title="Delete" class="block lg:hidden lg:group-hover:block hover:text-red-600 transition duration-300 px-2 md:px-6 xl:px-8">
                                    <i class="fa-solid fa-circle-xmark text-[22px] lg:text-4xl"></i>
                                </a>
                            <?php endif; ?>
                            <a href="/link" title="View" class="hover:text-green-600 transition duration-300">
                                <i class="fa-sharp fa-solid fa-circle-chevron-right text-[22px] lg:text-4xl"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="w-full lg:w-1/3 lg:h-[157px] lg:flex lg:justify-evenly lg:flex-col primary-opacity ml-0 lg:ml-4 text-center rounded-[4px] py-10 lg:py-4">
                    <h2 class="font-bold text-2xl">Rekapan Tugas</h2>
                    <h3 class="text-sm">Terakhir diubah <span class="font-bold">11 November 2022</span></h3>
                    <?php if(Auth::user()->level == 'admin'): ?>
                        <div class="flex justify-center">
                            <a href="/rekapan-create" title="Create" class="bg-sky-500 hover:bg-sky-600 w-1/2 font-semibold py-2 px-4 rounded-md text-white lg:text-[10px] xl:text-[15px]">
                                Tambah Tugas
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!-- End Rekap Section -->


    <script src="https://kit.fontawesome.com/a374d5ed26.js" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>
</html><?php /**PATH C:\laravel\weesia\resources\views/member/rekapan_crud.blade.php ENDPATH**/ ?>