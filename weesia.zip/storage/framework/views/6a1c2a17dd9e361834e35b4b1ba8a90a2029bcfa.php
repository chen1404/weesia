<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon picture" href="img/logo/code.png">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    
    <!-- Footer Section -->
    <footer id="footer" class="bg-dark py-8">
        <div class="sm:container px-4">
            <div class="flex justify-center">
                <h3 class="text-white text-xs font-semibold">copyright weesia 2022 all rights reserved.</h3>
            </div>
        </div>
    </footer>
    <!-- End Footer Section -->

    <script src="https://kit.fontawesome.com/a374d5ed26.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>
</head><?php /**PATH C:\laravel\weesia\resources\views/member/layouts/member.blade.php ENDPATH**/ ?>