<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
<link href="<?php echo e(asset('style/main.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('stylesheet/style.css')); ?>" rel="stylesheet" /><?php /**PATH C:\laravel\weesia\resources\views/includes/style.blade.php ENDPATH**/ ?>