<?php
    print_r($value);
?>

    
    <?php /**PATH C:\laravel\weesia\resources\views/test.blade.php ENDPATH**/ ?>