<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <!-- Header -->
    <header class="bg-transparent absolute top-0 left-0 w-full flex items-center z-10">
        <div class="sm:container px-4 w-full">
            <div class="flex items-center justify-between relative">
                <div class="">
                    <a href="#home" class="font-bold text-xl text-dark block my-6">WEESIA</a>
                </div>
                <div class="flex items-center px-4">

                    <nav id="nav-menu" class="hidden absolute py-5 bg-white shadow-xl rounded-lg max-w-[250px] w-full right-4 top-full lg:block lg:static lg:bg-transparent lg:max-w-full lg:shadow-none lg:rounded-none">
                        <ul class="block lg:flex">
                            <li class="group">
                                <a href="#home" class="navbar-menu active-page">Home</a>
                            </li>
                            <li class="group">
                                <a href="/rekapan" class="navbar-menu">Rekapan</a>
                            </li>
                            <li class="group">
                                <a href="#" class="navbar-menu">Aplikasi</a>
                            </li>
                            <li class="group">
                                <a href="#" class="navbar-menu">Kontak</a>
                            </li>
                        </ul>
                    </nav>
                </div>

                <div class="mr-12 lg:mr-0">
                    <a href="#" class="py-[6px] px-3 rounded-lg text-white hover:opacity-80 bg-primary text-base hover:cursor-pointer transition duration-700">Logout</a>
                </div>
                
                <button id="hamburger" name="hamburger" type="button" class="block absolute right-0 lg:hidden">
                    <span class="hamburger-line transition duration-700 ease-in-out origin-top-left"></span>
                    <span class="hamburger-line transition duration-700 ease-in-out"></span>
                    <span class="hamburger-line transition duration-700 ease-in-out origin-bottom-left"></span>
                </button>
            </div>
        </div>
    </header>
    <!-- End Header -->

    <!-- Hero Section -->
    <section id="home" class="pt-16 sm:pt-36 bg-white">
        <div class="sm:container p-4">
            <div class="sm:hidden text-center">
                <h1 class="text-dark text-2xl font-bold">Bergabung dengan<br>Weesia Member</h1>
            </div>
            <div class="flex mt-7 sm:mt-0">
                <div class="w-1/2 sm:mt-7 pr-6 sm:pr-0 lg:pr-20">
                    <h1 class="hidden sm:block text-dark text-2xl lg:text-4xl xl:text-5xl font-bold">Bergabung dengan</h1>
                    <h1 class="hidden sm:block text-dark text-2xl lg:text-4xl xl:text-5xl font-bold sm:mt-0 md:mt-3 lg:mt-5">Weesia Member</h1>
                    <p class="text-sm md:text-sm xl:text-lg font-semibold sm:text-start text-center text-dark mt-5">Weesia Member adalah sebuah platform menambah pemasukan dengan kerja sampingan yang dapat kerja dari mana saja dan kapan saja</p>
                    <div class="mt-7 flex justify-between sm:justify-start">
                        <a href="#benefit" class="border-[1px] rounded-md border-[#1BBC9D] px-[12px] sm:px-[15px] py-[2px] font-medium md:text-base xl:text-xl bg-opacity-20 bg-primary hover:bg-opacity-100 transition duration-700 mr-0 sm:mr-4">Benefit</a>
                        <a href="#modal" class="border-[1px] rounded-md border-[#1BBC9D] px-[10px] sm:px-[12px] py-[2px] font-medium md:text-base xl:text-xl bg-opacity-20 bg-primary hover:bg-opacity-100 transition duration-700">Modal</a>
                    </div>
                </div>
                <div class="w-1/2 flex justify-end relative">
                    <img src="img/person/person.png" alt="Person" class="md:h-80 xl:h-[400px] absolute bottom-0 md:-top-5 xl:-top-7">
                    <span class="block h-[240px] xl:h-[372px] md:h-[300px] w-[180px] xl:w-[280px] md:w-[225px] rounded-t-md bg-primary"></span>
                </div>
            </div>
        </div>
    </section>
    <!-- End Hero Section -->

    <!-- About Section -->
    <section id="modal" class="bg-[#F8FCFB] mt-24 py-8">
        <div class="sm:container p-4 md:px-36 lg:px-64 flex items-center">
            <h1 class="font-bold text-2xl lg:text-4xl">Weesia</h1>
            <div class="border-r-[3px] md:border-r-4 border-primary w-16 h-24 md:h-28 lg:h-32"></div>
            <p class="font-semibold text-[10px] md:text-sm xl:text-lg ml-4">Sederhananya bisnis ini bergerak dibidang yaitu menaikkan jumlah followers dari official account Line secara manual. Kita hanya perlu membuat Akun Line sebanyak-banyaknya dengan cara yang telah ditentukan.</p>
        </div>
    </section>
    <!-- End About Section -->

    <!-- Modal Section -->
    <section id="modall" class="bg-white">
        <div class="sm:container px-4 xl:px-64 py-16">
            <h1 class="font-bold text-2xl lg:text-4xl text-center">Modal</h1>
            <div class="flex flex-row justify-between mt-7">
                <div class="flex flex-col text-center justify-center items-center md:px-12 xl:px-8">
                    <div class="bg-primary py-2 rounded-lg bg-opacity-30 h-10 w-10 md:h-14 md:w-14">
                        <i class="fa-solid fa-sim-card text-primary text-2xl md:text-4xl"></i>
                    </div>
                    <h2 class="font-bold text-base md:text-lg mt-3">SIM Card</h2>
                    <p class="text-[8px] lg:text-xs font-medium">Nomor Hp yang aktif diperlukan untuk selangkah menjadi bagian dari kami!</p>
                </div>
                <div class="flex flex-col text-center justify-center items-center md:px-12 xl:px-8">
                    <div class="bg-primary py-2 rounded-lg bg-opacity-30 h-10 w-10 md:h-14 md:w-14">
                        <i class="fa-solid fa-mobile-screen text-primary text-2xl md:text-4xl"></i>
                    </div>
                    <h2 class="font-bold text-base md:text-lg mt-3">Handphone</h2>
                    <p class="text-[8px] lg:text-xs font-medium">Pastikan Hp yang dimiliki Hp Android yah. Dan Hpnya milik pribadi bukan punya mantan!</p>
                </div>
                <div class="flex flex-col text-center justify-center items-center md:px-12 xl:px-8">
                    <div class="bg-primary py-2 rounded-lg bg-opacity-30 h-10 w-10 md:h-14 md:w-14">
                        <i class="fa-solid fa-sd-card text-primary text-2xl md:text-4xl"></i>
                    </div>
                    <h2 class="font-bold text-base md:text-lg mt-3">Memory</h2>
                    <p class="text-[8px] lg:text-xs font-medium">Pastikan Hp yang digunakan memiliki memori internal yang tersisa minimal 5 Gb!</p>
                </div>
            </div>
        </div>
    </section>
    <!-- End Modal Section -->

    <!-- Benefit Section -->
    <section id="benefit" class="bg-primary flex justify-center text-center py-12">
        <div class="sm:container">
            <h1 class="font-bold text-2xl lg:text-4xl text-center">Benefit yang didapat</h1>
            <div class="flex justify-center">
                <ul class="text-start px-11 mt-4 lg:mt-7">
                    <li class="font-bold text-sm mb-2 md:mb-4"><i class="fa-solid fa-circle-check"></i> Jam Kerja Fleksibel</li>
                    <li class="font-bold text-sm mb-2 md:mb-4"><i class="fa-solid fa-circle-check"></i> Bonus</li>
                    <li class="font-bold text-sm mb-2 md:mb-4"><i class="fa-solid fa-circle-check"></i> Menambah Relasi</li>
                    <li class="font-bold text-sm mb-2 md:mb-4"><i class="fa-solid fa-circle-check"></i> Gaji</li>
                    <li class="font-bold text-sm mb-2 md:mb-4"><i class="fa-solid fa-circle-check"></i> Kerja dari mana saja</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- End Benefit Section -->

    <!-- Footer Section -->
    <footer id="footer" class="bg-dark py-8">
        <div class="container">
            <div class="flex justify-center">
                <h3 class="text-white text-xs font-semibold">copyright weesia 2022 all rights reserved.</h3>
            </div>
        </div>
    </footer>
    <!-- End Footer Section -->


    <script src="https://kit.fontawesome.com/a374d5ed26.js" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>
</html><?php /**PATH C:\laravel\weesia\resources\views/home.blade.php ENDPATH**/ ?>