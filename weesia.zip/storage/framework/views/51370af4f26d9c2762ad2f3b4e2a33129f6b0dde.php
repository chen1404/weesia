<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th style="font-weight: bold; vertical-align: middle; text-align: center;">NAMA</th>
                <?php $__currentLoopData = $colDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th style="font-weight: bold; vertical-align: middle; text-align: center;"><?php echo e($colDate[0]->absen->date); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th style="font-weight: bold; vertical-align: middle; text-align: center;">Alpha</th>
                <th style="font-weight: bold; vertical-align: middle; text-align: center;">Telat</th>
                <th style="font-weight: bold; vertical-align: middle; text-align: center;">Izin</th>
                <th style="font-weight: bold; vertical-align: middle; text-align: center;"><?php echo e($task); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $acumulations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acumulation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php $__currentLoopData = $rowNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($acumulation->name == $userName->name): ?>
                            <td style="font-weight: bold; vertical-align: middle; text-align: center;" rowspan="2"><?php echo e($userName->name); ?></td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php $elseTask = $task == 'Bot' ? 'Clone' : 'Bot'; ?>
                    <?php $__currentLoopData = $rowDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($userData->user->name == $acumulation->name && $userData->task != $elseTask): ?>
                            <td style="vertical-align: middle; text-align: center;"><?php echo e($userData->status_desc); ?></td>
                        <?php elseif($userData->user->name == $acumulation->name): ?>
                            <td style="vertical-align: middle; text-align: center;"> - </td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <td style="vertical-align: middle; text-align: center;" rowspan="2"><?php echo e($acumulation->alphas); ?></td>
                    <td style="vertical-align: middle; text-align: center;" rowspan="2"><?php echo e($acumulation->telats); ?></td>
                    <td style="vertical-align: middle; text-align: center;" rowspan="2"><?php echo e($acumulation->izins); ?></td>
                    <td style="vertical-align: middle; text-align: center;" rowspan="2"><?php echo e($task == 'Bot' ? $acumulation->bots : $acumulation->clones); ?></td>
                </tr>
                <tr>
                    <?php $__currentLoopData = $rowDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($userData->user->name == $acumulation->name && ($userData->task == $task || $userData->task == 'Lainnya')): ?>
                            <td style="vertical-align: middle; text-align: center;"><?php echo e($userData->task_desc); ?></td>
                        <?php elseif($userData->user->name == $acumulation->name): ?>
                            <td style="vertical-align: middle; text-align: center;"> - </td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\laravel\weesia\resources\views/dashboard/export/absen.blade.php ENDPATH**/ ?>