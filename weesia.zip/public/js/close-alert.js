
function closeAlert() {
    var alertDiv = document.getElementById("alert");
    // alertDiv.classList.remove('lg:flex');
    alertDiv.classList.add('hidden');
}