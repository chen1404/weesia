<?php return array (
  'TOKEN_MEMBER' => '3P05SJX',
);